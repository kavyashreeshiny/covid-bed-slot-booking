-- Booking procedure: refuses overlapping bookings for the same bed (MySQL 8)
USE covid_bed_booking;
DROP PROCEDURE IF EXISTS book_bed;
DELIMITER //
CREATE PROCEDURE book_bed(
    IN p_patient_id INT, IN p_bed_id INT, IN p_admit DATE, IN p_discharge DATE)
BEGIN
    DECLARE v_conflicts INT;
    SELECT COUNT(*) INTO v_conflicts
    FROM booking
    WHERE bed_id = p_bed_id
      AND status IN ('Confirmed', 'Admitted')
      AND admit_date < COALESCE(p_discharge, '9999-12-31')
      AND COALESCE(discharge_date, '9999-12-31') > p_admit;

    IF v_conflicts > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bed already booked for the requested dates';
    END IF;

    INSERT INTO booking (patient_id, bed_id, booking_date, admit_date, discharge_date, status)
    VALUES (p_patient_id, p_bed_id, CURDATE(), p_admit, p_discharge, 'Confirmed');
END //
DELIMITER ;

-- Example: CALL book_bed(1, 10, '2025-07-01', '2025-07-08');
