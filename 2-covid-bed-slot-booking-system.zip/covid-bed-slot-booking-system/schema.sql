-- COVID-19 Bed Slot Booking System - schema (MySQL 8)
DROP DATABASE IF EXISTS covid_bed_booking;
CREATE DATABASE covid_bed_booking;
USE covid_bed_booking;

CREATE TABLE hospital (
    hospital_id   INT PRIMARY KEY AUTO_INCREMENT,
    name          VARCHAR(100) NOT NULL UNIQUE,
    city          VARCHAR(50)  NOT NULL,
    phone         VARCHAR(15)  NOT NULL
);

CREATE TABLE ward (
    ward_id       INT PRIMARY KEY AUTO_INCREMENT,
    hospital_id   INT NOT NULL,
    ward_type     VARCHAR(20) NOT NULL CHECK (ward_type IN ('General', 'Oxygen', 'ICU', 'Ventilator')),
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id) ON DELETE CASCADE,
    UNIQUE (hospital_id, ward_type)
);

CREATE TABLE bed (
    bed_id        INT PRIMARY KEY AUTO_INCREMENT,
    ward_id       INT NOT NULL,
    bed_number    VARCHAR(10) NOT NULL,
    status        VARCHAR(15) NOT NULL DEFAULT 'Available' CHECK (status IN ('Available', 'Occupied', 'Maintenance')),
    FOREIGN KEY (ward_id) REFERENCES ward(ward_id) ON DELETE CASCADE,
    UNIQUE (ward_id, bed_number)
);

CREATE TABLE patient (
    patient_id    INT PRIMARY KEY AUTO_INCREMENT,
    full_name     VARCHAR(100) NOT NULL,
    age           INT NOT NULL CHECK (age BETWEEN 0 AND 120),
    gender        VARCHAR(10) NOT NULL CHECK (gender IN ('Male', 'Female', 'Other')),
    phone         VARCHAR(15) NOT NULL,
    city          VARCHAR(50) NOT NULL,
    severity      VARCHAR(10) NOT NULL CHECK (severity IN ('Mild', 'Moderate', 'Severe', 'Critical'))
);

CREATE TABLE booking (
    booking_id      INT PRIMARY KEY AUTO_INCREMENT,
    patient_id      INT NOT NULL,
    bed_id          INT NOT NULL,
    booking_date    DATE NOT NULL,
    admit_date      DATE NOT NULL,
    discharge_date  DATE NULL,
    status          VARCHAR(15) NOT NULL DEFAULT 'Confirmed' CHECK (status IN ('Confirmed', 'Admitted', 'Discharged', 'Cancelled')),
    FOREIGN KEY (patient_id) REFERENCES patient(patient_id),
    FOREIGN KEY (bed_id) REFERENCES bed(bed_id),
    CHECK (discharge_date IS NULL OR discharge_date >= admit_date),
    CHECK (admit_date >= booking_date)
);

CREATE INDEX idx_booking_bed_dates ON booking (bed_id, admit_date, discharge_date);
CREATE INDEX idx_bed_status ON bed (status);
