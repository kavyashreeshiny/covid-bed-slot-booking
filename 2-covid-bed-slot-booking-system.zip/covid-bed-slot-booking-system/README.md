# COVID-19 Bed Slot Booking System

Relational database for managing patient, hospital and bed-availability data, with slot bookings.

**Tools:** MySQL 8, SQL

## Design
`hospital` -> `ward` -> `bed` -> `booking` <- `patient` (normalized to 3NF).
Constraints: primary/foreign keys, UNIQUE, CHECK (ward type, severity, status, date order), indexes on booking dates.

## Files
| File | Purpose |
|---|---|
| `schema.sql` | Tables, constraints, indexes |
| `sample_data.sql` | Fictional hospitals, beds, patients, bookings |
| `queries.sql` | 10 queries: joins, aggregation, subqueries, CTE, window functions, view |
| `procedures.sql` | `book_bed` stored procedure that blocks overlapping bookings |

## Run
```bash
mysql -u root -p < schema.sql
mysql -u root -p < sample_data.sql
mysql -u root -p < queries.sql
mysql -u root -p < procedures.sql
```
All data is fictional.
