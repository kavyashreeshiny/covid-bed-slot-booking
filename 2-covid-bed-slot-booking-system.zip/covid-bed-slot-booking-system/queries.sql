-- COVID-19 Bed Slot Booking System - analysis queries
USE covid_bed_booking;

-- 1. Available beds per hospital and ward type
SELECT h.name AS hospital, w.ward_type, COUNT(*) AS available_beds
FROM bed b
JOIN ward w     ON w.ward_id = b.ward_id
JOIN hospital h ON h.hospital_id = w.hospital_id
WHERE b.status = 'Available'
GROUP BY h.name, w.ward_type
ORDER BY h.name, w.ward_type;

-- 2. Occupancy rate per hospital
SELECT h.name AS hospital,
       COUNT(*) AS total_beds,
       SUM(b.status = 'Occupied') AS occupied,
       ROUND(100.0 * SUM(b.status = 'Occupied') / COUNT(*), 1) AS occupancy_pct
FROM bed b
JOIN ward w     ON w.ward_id = b.ward_id
JOIN hospital h ON h.hospital_id = w.hospital_id
GROUP BY h.name
ORDER BY occupancy_pct DESC;

-- 3. Active bookings with patient, hospital and bed details
SELECT bk.booking_id, p.full_name, p.severity, h.name AS hospital, w.ward_type, b.bed_number, bk.admit_date, bk.status
FROM booking bk
JOIN patient p  ON p.patient_id = bk.patient_id
JOIN bed b      ON b.bed_id = bk.bed_id
JOIN ward w     ON w.ward_id = b.ward_id
JOIN hospital h ON h.hospital_id = w.hospital_id
WHERE bk.status IN ('Confirmed', 'Admitted')
ORDER BY bk.admit_date;

-- 4. Average length of stay by ward type (discharged patients)
SELECT w.ward_type,
       COUNT(*) AS discharges,
       ROUND(AVG(DATEDIFF(bk.discharge_date, bk.admit_date)), 1) AS avg_stay_days
FROM booking bk
JOIN bed b  ON b.bed_id = bk.bed_id
JOIN ward w ON w.ward_id = b.ward_id
WHERE bk.status = 'Discharged'
GROUP BY w.ward_type
ORDER BY avg_stay_days DESC;

-- 5. Patients with no booking (unallocated demand)
SELECT p.patient_id, p.full_name, p.severity, p.city
FROM patient p
LEFT JOIN booking bk ON bk.patient_id = p.patient_id
WHERE bk.booking_id IS NULL;

-- 6. ICU beds free for a requested stay (no overlapping active booking)
--    Replace the two dates with the requested admit / expected discharge dates.
SELECT h.name AS hospital, w.ward_type, b.bed_number
FROM bed b
JOIN ward w     ON w.ward_id = b.ward_id
JOIN hospital h ON h.hospital_id = w.hospital_id
WHERE w.ward_type = 'ICU'
  AND b.status <> 'Maintenance'
  AND NOT EXISTS (
      SELECT 1 FROM booking bk
      WHERE bk.bed_id = b.bed_id
        AND bk.status IN ('Confirmed', 'Admitted', 'Discharged')
        AND bk.admit_date < '2025-06-20'
        AND COALESCE(bk.discharge_date, '9999-12-31') > '2025-06-10'
  );

-- 7. Rank hospitals by number of bookings (window function)
SELECT hospital, bookings, RANK() OVER (ORDER BY bookings DESC) AS booking_rank
FROM (
    SELECT h.name AS hospital, COUNT(*) AS bookings
    FROM booking bk
    JOIN bed b      ON b.bed_id = bk.bed_id
    JOIN ward w     ON w.ward_id = b.ward_id
    JOIN hospital h ON h.hospital_id = w.hospital_id
    GROUP BY h.name
) t;

-- 8. Running total of bookings by date (CTE + window function)
WITH daily AS (
    SELECT booking_date, COUNT(*) AS bookings FROM booking GROUP BY booking_date
)
SELECT booking_date, bookings, SUM(bookings) OVER (ORDER BY booking_date) AS running_total
FROM daily
ORDER BY booking_date;

-- 9. Bookings by patient severity and status
SELECT p.severity, bk.status, COUNT(*) AS bookings
FROM booking bk
JOIN patient p ON p.patient_id = bk.patient_id
GROUP BY p.severity, bk.status
ORDER BY FIELD(p.severity, 'Critical', 'Severe', 'Moderate', 'Mild'), bk.status;

-- 10. Reusable view: current bed availability
CREATE OR REPLACE VIEW v_bed_availability AS
SELECT h.hospital_id, h.name AS hospital, h.city, w.ward_type,
       COUNT(*) AS total_beds,
       SUM(b.status = 'Available') AS available_beds
FROM bed b
JOIN ward w     ON w.ward_id = b.ward_id
JOIN hospital h ON h.hospital_id = w.hospital_id
GROUP BY h.hospital_id, h.name, h.city, w.ward_type;
